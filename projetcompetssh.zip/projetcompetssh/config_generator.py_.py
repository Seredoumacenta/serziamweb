import json
import base64
import random
import string
import hashlib
import zlib
import secrets
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
import socket

class NPVTConfigGenerator:
    """Générateur de configuration NPVT-SSH optimisée"""
    
    def __init__(self):
        self.payload_stats = []
        
    def _generate_credentials(self) -> Dict[str, str]:
        """Génère des identifiants SSH uniques"""
        username = f"vps{random.randint(10000, 99999)}"
        
        # Mot de passe robuste
        password_chars = string.ascii_letters + string.digits + "!@#$%&*"
        password = ''.join(secrets.choice(password_chars) for _ in range(20))
        
        return {
            "username": username,
            "password": password,
            "created_at": datetime.now().isoformat()
        }
    
    def _generate_sni(self) -> str:
        """Génère un SNI crédible"""
        domains = [
            "cloudflare.com", "googleapis.com", "akamai.net",
            "fastly.com", "azureedge.net", "aws.com",
            "cdn77.org", "stackpath.com", "fastly.net"
        ]
        
        subdomains = [
            "cdn", "static", "assets", "api", "video",
            "download", "stream", "content", "edge", "media"
        ]
        
        return f"{random.choice(subdomains)}.{random.choice(domains)}"
    
    def _generate_payload_stats(self, criterion: str) -> Dict[str, Any]:
        """Génère les statistiques du payload sans révéler le payload lui-même"""
        
        # Paramètres basés sur le critère
        if criterion == "economy":
            compression = random.randint(95, 99)
            speed = random.randint(70, 85)
            reliability = random.randint(80, 90)
            stability = "B"
            encryption = "AES128-GCM"
        elif criterion == "reliability":
            compression = random.randint(90, 95)
            speed = random.randint(80, 90)
            reliability = random.randint(95, 99)
            stability = "A"
            encryption = "AES256-GCM"
        elif criterion == "speed":
            compression = random.randint(85, 92)
            speed = random.randint(95, 99)
            reliability = random.randint(85, 95)
            stability = "S"
            encryption = "CHACHA20-POLY1305"
        else:  # balanced
            compression = random.randint(88, 96)
            speed = random.randint(85, 95)
            reliability = random.randint(88, 96)
            stability = random.choice(["A", "B"])
            encryption = random.choice(["AES128", "CHACHA20"])
        
        return {
            "criterion": criterion,
            "compression_percentage": compression,
            "speed_percentage": speed,
            "reliability_percentage": reliability,
            "stability": stability,
            "encryption": encryption,
            "generated_at": datetime.now().isoformat(),
            "expires_in": random.choice([1, 7, 15, 30]),  # jours
            "device_limit": 1,
            "unique_id": secrets.token_hex(8)
        }
    
    def _generate_payload(self, stats: Dict[str, Any]) -> str:
        """Génère le payload réel (secret)"""
        payload_parts = [
            f"ID:{stats['unique_id']}",
            f"CR:{stats['criterion']}",
            f"CP:{stats['compression_percentage']:02d}",
            f"SP:{stats['speed_percentage']:02d}",
            f"RL:{stats['reliability_percentage']:02d}",
            f"ST:{stats['stability']}",
            f"EN:{stats['encryption'][:8]}",
            f"TS:{int(datetime.now().timestamp())}",
            f"EX:{stats['expires_in']}",
            f"DL:{stats['device_limit']}"
        ]
        
        payload_str = "|".join(payload_parts)
        compressed = zlib.compress(payload_str.encode('utf-8'), level=9)
        return base64.b64encode(compressed).decode('utf-8')
    
    def generate_config(self, vps_ip: str, vps_port: int, 
                       criterion: str, duration_days: int) -> Dict[str, Any]:
        """Génère une configuration complète NPVT-SSH"""
        
        # Générer les statistiques (visibles par l'utilisateur)
        stats = self._generate_payload_stats(criterion)
        stats["expires_in"] = duration_days
        
        # Générer le payload (secret)
        payload_b64 = self._generate_payload(stats)
        
        # Générer les identifiants
        credentials = self._generate_credentials()
        
        # Générer SNI
        sni = self._generate_sni()
        
        # Construire la configuration
        config = {
            "sshConfigType": "SSH-TLS-Payload",
            "remarks": f"VPS-{vps_ip.replace('.', '-')}-{stats['unique_id'][:6]}",
            "sshHost": vps_ip,
            "sshPort": 443,
            "sshUsername": credentials["username"],
            "sshPassword": credentials["password"],
            "sni": sni,
            "tlsVersion": "DEFAULT",
            "payload": payload_b64,
            "dnsTTLMode": "UDP",
            "dnsServer": "1.1.1.1",
            "nameserver": "8.8.8.8",
            "udpgwPort": 7300,
            "udpgwTransparentDNS": True,
            "locked": True,
            "websocket": True,
            "tlsPort": 443,
            "websocketPath": "/ws",
            "transport": "websocket",
            "alpn": "h2,http/1.1",
            "fingerprint": "chrome",
            "padding": True,
            "mux": True,
            "muxConcurrency": 8,
            "metadata": {
                "generated_at": datetime.now().isoformat(),
                "expires_at": (datetime.now() + timedelta(days=duration_days)).isoformat(),
                "vps_ip": vps_ip,
                "vps_port": vps_port,
                "device_limit": 1,
                "config_id": stats['unique_id'],
                "criterion": criterion
            }
        }
        
        # Convertir en URL NPVT
        config_json = json.dumps(config, separators=(',', ':'))
        config_b64 = base64.b64encode(config_json.encode()).decode()
        final_config = f"npvt-ssh://{config_b64}"
        
        return {
            'stats': stats,  # Visible par l'utilisateur
            'config': config,  # Stocké côté serveur
            'final_config': final_config,  # Visible par l'utilisateur
            'credentials': credentials,
            'vps_info': {
                'ip': vps_ip,
                'port': vps_port
            },
            'duration_days': duration_days
        }
    
    def validate_vps_connection(self, ip: str, port: int) -> bool:
        """Valide la connexion au VPS"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex((ip, port))
            sock.close()
            return result == 0
        except:
            return False