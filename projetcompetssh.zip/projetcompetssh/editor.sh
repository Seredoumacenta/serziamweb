cp .env.example .env
# Éditez le fichier .env avec vos paramètres