// Scripts généraux pour l'application

// Gestion des tooltips
function initTooltips() {
    const tooltips = document.querySelectorAll('[data-tooltip]');
    tooltips.forEach(element => {
        element.addEventListener('mouseenter', function(e) {
            const tooltipText = this.getAttribute('data-tooltip');
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = tooltipText;
            
            document.body.appendChild(tooltip);
            
            const rect = this.getBoundingClientRect();
            tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
            tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
            
            this._tooltip = tooltip;
        });
        
        element.addEventListener('mouseleave', function() {
            if (this._tooltip) {
                this._tooltip.remove();
                this._tooltip = null;
            }
        });
    });
}

// Gestion du temps restant
function updateCountdowns() {
    const countdownElements = document.querySelectorAll('[data-expires]');
    
    countdownElements.forEach(element => {
        const expires = new Date(element.getAttribute('data-expires'));
        const now = new Date();
        const diff = expires - now;
        
        if (diff <= 0) {
            element.textContent = 'Expirée';
            element.classList.add('expired');
            return;
        }
        
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        
        if (days > 0) {
            element.textContent = `${days} jour${days > 1 ? 's' : ''} ${hours}h`;
        } else {
            element.textContent = `${hours} heure${hours > 1 ? 's' : ''}`;
        }
    });
}

// Validation des formulaires
function initFormValidation() {
    const forms = document.querySelectorAll('form[data-validate]');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const inputs = this.querySelectorAll('[required]');
            let isValid = true;
            
            inputs.forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                    input.classList.add('error');
                    
                    // Créer un message d'erreur
                    let errorMsg = input.nextElementSibling;
                    if (!errorMsg || !errorMsg.classList.contains('error-msg')) {
                        errorMsg = document.createElement('div');
                        errorMsg.className = 'error-msg';
                        errorMsg.textContent = 'Ce champ est requis';
                        input.parentNode.insertBefore(errorMsg, input.nextSibling);
                    }
                } else {
                    input.classList.remove('error');
                    const errorMsg = input.nextElementSibling;
                    if (errorMsg && errorMsg.classList.contains('error-msg')) {
                        errorMsg.remove();
                    }
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                return false;
            }
        });
    });
}

// Gestion des onglets
function initTabs() {
    const tabContainers = document.querySelectorAll('.tabs');
    
    tabContainers.forEach(container => {
        const tabs = container.querySelectorAll('.tab-btn');
        const tabContents = container.querySelectorAll('.tab-content');
        
        tabs.forEach(tab => {
            tab.addEventListener('click', function() {
                const tabId = this.getAttribute('data-tab');
                
                // Désactiver tous les onglets
                tabs.forEach(t => t.classList.remove('active'));
                tabContents.forEach(c => c.classList.remove('active'));
                
                // Activer l'onglet courant
                this.classList.add('active');
                document.getElementById(tabId).classList.add('active');
            });
        });
    });
}

// Copie de texte améliorée
function initCopyButtons() {
    document.addEventListener('click', function(e) {
        if (e.target.closest('[data-copy]')) {
            const button = e.target.closest('[data-copy]');
            const targetId = button.getAttribute('data-copy');
            const target = document.getElementById(targetId);
            
            if (target) {
                const text = target.value || target.textContent;
                
                navigator.clipboard.writeText(text).then(() => {
                    const originalText = button.innerHTML;
                    button.innerHTML = '<i class="fas fa-check"></i> Copié!';
                    button.classList.add('copied');
                    
                    setTimeout(() => {
                        button.innerHTML = originalText;
                        button.classList.remove('copied');
                    }, 2000);
                }).catch(err => {
                    console.error('Erreur lors de la copie:', err);
                    button.innerHTML = '<i class="fas fa-times"></i> Erreur';
                    button.classList.add('error');
                    
                    setTimeout(() => {
                        button.innerHTML = originalText;
                        button.classList.remove('error');
                    }, 2000);
                });
            }
        }
    });
}

// Animation des éléments au scroll
function initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
            }
        });
    }, {
        threshold: 0.1
    });
    
    document.querySelectorAll('.animate-on-scroll').forEach(element => {
        observer.observe(element);
    });
}

// Gestion des sessions utilisateur
function initUserSession() {
    // Vérifier si la session existe
    if (!localStorage.getItem('user_session_initialized')) {
        // Créer une nouvelle session
        const sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('user_session_id', sessionId);
        localStorage.setItem('user_session_initialized', 'true');
        localStorage.setItem('user_session_created', new Date().toISOString());
    }
    
    // Rafraîchir la session toutes les 30 minutes
    setInterval(() => {
        localStorage.setItem('user_session_last_active', new Date().toISOString());
    }, 30 * 60 * 1000);
}

// Initialisation globale
document.addEventListener('DOMContentLoaded', function() {
    initTooltips();
    initFormValidation();
    initTabs();
    initCopyButtons();
    initScrollAnimations();
    initUserSession();
    
    // Mettre à jour les compteurs à rebours
    updateCountdowns();
    setInterval(updateCountdowns, 60000); // Toutes les minutes
    
    // Gestion du thème sombre/clair
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-theme');
            localStorage.setItem('theme', document.body.classList.contains('dark-theme') ? 'dark' : 'light');
        });
        
        // Restaurer le thème
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.body.classList.add('dark-theme');
        }
    }
    
    // Confirmation pour les actions importantes
    document.addEventListener('click', function(e) {
        if (e.target.closest('[data-confirm]')) {
            const message = e.target.closest('[data-confirm]').getAttribute('data-confirm');
            if (!confirm(message)) {
                e.preventDefault();
                e.stopPropagation();
            }
        }
    });
});

// API helper functions
class API {
    static async request(endpoint, method = 'GET', data = null) {
        const headers = {
            'Content-Type': 'application/json',
        };
        
        const options = {
            method,
            headers,
            credentials: 'same-origin'
        };
        
        if (data) {
            options.body = JSON.stringify(data);
        }
        
        try {
            const response = await fetch(endpoint, options);
            const result = await response.json();
            
            if (!response.ok) {
                throw new Error(result.message || 'Erreur API');
            }
            
            return result;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }
    
    static async get(endpoint) {
        return this.request(endpoint, 'GET');
    }
    
    static async post(endpoint, data) {
        return this.request(endpoint, 'POST', data);
    }
    
    static async put(endpoint, data) {
        return this.request(endpoint, 'PUT', data);
    }
    
    static async delete(endpoint) {
        return this.request(endpoint, 'DELETE');
    }
}

// Exposer l'API globalement
window.API = API;

// Formatters
const Formatters = {
    formatDate: (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleDateString('fr-FR', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    },
    
    formatBytes: (bytes) => {
        const units = ['B', 'KB', 'MB', 'GB'];
        let size = bytes;
        let unitIndex = 0;
        
        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }
        
        return `${size.toFixed(2)} ${units[unitIndex]}`;
    },
    
    formatDuration: (seconds) => {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        
        if (hours > 0) {
            return `${hours}h ${minutes}m`;
        } else if (minutes > 0) {
            return `${minutes}m ${secs}s`;
        } else {
            return `${secs}s`;
        }
    }
};

window.Formatters = Formatters;