from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import os
from datetime import datetime, timedelta
import secrets
import socket

from config import Config
from utils.config_generator import NPVTConfigGenerator
from utils.payload_stats import PayloadStatsManager

# Initialisation Flask
app = Flask(__name__)
app.config.from_object(Config)

# Initialisation extensions
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'admin_login'
login_manager.login_message = 'Veuillez vous connecter pour accéder à cette page.'

# Initialisation managers
config_generator = NPVTConfigGenerator()
stats_manager = PayloadStatsManager()

# Modèles de base de données
class UserConfig(db.Model):
    """Stockage des configurations utilisateur"""
    id = db.Column(db.Integer, primary_key=True)
    config_id = db.Column(db.String(64), unique=True, nullable=False)
    user_session_id = db.Column(db.String(128), nullable=False)
    vps_ip = db.Column(db.String(45), nullable=False)
    vps_port = db.Column(db.Integer, nullable=False)
    criterion = db.Column(db.String(20), nullable=False)
    duration_days = db.Column(db.Integer, nullable=False)
    final_config = db.Column(db.Text, nullable=False)
    stats_data = db.Column(db.Text, nullable=False)  # JSON des stats
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    
    def to_dict(self):
        return {
            'config_id': self.config_id,
            'vps_ip': self.vps_ip,
            'criterion': self.criterion,
            'duration_days': self.duration_days,
            'created_at': self.created_at.isoformat(),
            'expires_at': self.expires_at.isoformat(),
            'is_active': self.is_active
        }

class AdminUser(UserMixin, db.Model):
    """Utilisateur administrateur"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    vps_access_key = db.Column(db.String(128))
    last_login = db.Column(db.DateTime)
    is_superadmin = db.Column(db.Boolean, default=False)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

@login_manager.user_loader
def load_user(user_id):
    return AdminUser.query.get(int(user_id))

# Fonctions utilitaires
def check_vps_admin_access(ip: str, port: int) -> bool:
    """Vérifie l'accès admin via VPS"""
    try:
        # Simuler une vérification VPS
        # Dans la réalité, vous implémenteriez une authentification SSH
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(3)
        result = sock.connect_ex((ip, port))
        sock.close()
        
        # Pour cet exemple, nous acceptons si le port est ouvert
        # En production, implémentez une vraie authentification
        return result == 0
    except:
        return False

def get_user_session_id():
    """Génère ou récupère l'ID de session utilisateur"""
    if 'user_session_id' not in session:
        session['user_session_id'] = secrets.token_hex(32)
    return session['user_session_id']

# Routes publiques
@app.route('/')
def index():
    """Page d'accueil avec choix de configuration"""
    performance_stats = stats_manager.get_performance_stats()
    return render_template('index.html', 
                         performance_stats=performance_stats,
                         session_id=get_user_session_id())

@app.route('/api/validate-vps', methods=['POST'])
def validate_vps():
    """Valide la connexion au VPS"""
    data = request.get_json()
    vps_ip = data.get('vps_ip', '').strip()
    vps_port = int(data.get('vps_port', 22))
    
    if not vps_ip:
        return jsonify({'valid': False, 'message': 'Adresse IP requise'})
    
    is_valid = config_generator.validate_vps_connection(vps_ip, vps_port)
    
    return jsonify({
        'valid': is_valid,
        'message': 'VPS validé avec succès' if is_valid else 'Impossible de se connecter au VPS'
    })

@app.route('/api/generate-config', methods=['POST'])
def generate_config():
    """Génère une configuration pour l'utilisateur"""
    data = request.get_json()
    
    # Récupération des paramètres
    vps_ip = data.get('vps_ip', '').strip()
    vps_port = int(data.get('vps_port', 22))
    criterion = data.get('criterion', 'balanced')
    duration_days = int(data.get('duration_days', 15))
    
    # Validation
    if not vps_ip:
        return jsonify({'success': False, 'message': 'Adresse IP requise'})
    
    if duration_days < 1 or duration_days > 30:
        return jsonify({'success': False, 'message': 'Durée invalide (1-30 jours)'})
    
    # Vérifier si le VPS est accessible
    if not config_generator.validate_vps_connection(vps_ip, vps_port):
        return jsonify({'success': False, 'message': 'VPS inaccessible'})
    
    # Générer la configuration
    try:
        result = config_generator.generate_config(vps_ip, vps_port, criterion, duration_days)
        
        # Enregistrer dans la base de données
        user_config = UserConfig(
            config_id=result['stats']['unique_id'],
            user_session_id=get_user_session_id(),
            vps_ip=vps_ip,
            vps_port=vps_port,
            criterion=criterion,
            duration_days=duration_days,
            final_config=result['final_config'],
            stats_data=json.dumps(result['stats']),
            expires_at=datetime.utcnow() + timedelta(days=duration_days),
            is_active=True
        )
        
        db.session.add(user_config)
        db.session.commit()
        
        # Mettre à jour les statistiques
        stats_manager.add_config_stat(criterion, duration_days, result['stats'])
        
        return jsonify({
            'success': True,
            'final_config': result['final_config'],
            'stats': result['stats'],
            'config_id': result['stats']['unique_id']
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erreur: {str(e)}'})

@app.route('/my-config/<config_id>')
def view_config(config_id):
    """Affiche une configuration spécifique"""
    user_session_id = get_user_session_id()
    config = UserConfig.query.filter_by(
        config_id=config_id, 
        user_session_id=user_session_id,
        is_active=True
    ).first()
    
    if not config:
        flash('Configuration non trouvée ou expirée', 'error')
        return redirect(url_for('index'))
    
    stats = json.loads(config.stats_data)
    
    return render_template('user_config.html',
                         final_config=config.final_config,
                         stats=stats,
                         config=config)

@app.route('/api/my-configs')
def get_my_configs():
    """Récupère les configurations de l'utilisateur actuel"""
    user_session_id = get_user_session_id()
    configs = UserConfig.query.filter_by(
        user_session_id=user_session_id,
        is_active=True
    ).order_by(UserConfig.created_at.desc()).all()
    
    configs_list = [cfg.to_dict() for cfg in configs]
    
    return jsonify({
        'success': True,
        'configs': configs_list,
        'count': len(configs_list)
    })

# Routes admin (protégées par VPS)
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """Connexion admin via VPS"""
    if request.method == 'POST':
        vps_ip = request.form.get('vps_ip', '').strip()
        vps_port = int(request.form.get('vps_port', app.config['ADMIN_VPS_PORT']))
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        
        # Vérifier l'accès VPS
        if not check_vps_admin_access(vps_ip, vps_port):
            flash('Accès VPS refusé', 'error')
            return render_template('admin_login.html')
        
        # Vérifier les identifiants admin
        admin = AdminUser.query.filter_by(username=username).first()
        if admin and admin.check_password(password):
            login_user(admin)
            admin.last_login = datetime.utcnow()
            db.session.commit()
            
            flash('Connexion admin réussie', 'success')
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Identifiants incorrects', 'error')
    
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    """Tableau de bord administrateur"""
    dashboard_stats = stats_manager.get_dashboard_stats()
    
    # Statistiques détaillées
    total_configs = UserConfig.query.count()
    active_configs = UserConfig.query.filter_by(is_active=True).count()
    expired_configs = UserConfig.query.filter(
        UserConfig.expires_at < datetime.utcnow(),
        UserConfig.is_active == True
    ).count()
    
    # Configurations récentes
    recent_configs = UserConfig.query.order_by(
        UserConfig.created_at.desc()
    ).limit(50).all()
    
    # Répartition par critère
    criteria_stats = db.session.query(
        UserConfig.criterion,
        db.func.count(UserConfig.id).label('count')
    ).group_by(UserConfig.criterion).all()
    
    return render_template('admin_dashboard.html',
                         dashboard_stats=dashboard_stats,
                         total_configs=total_configs,
                         active_configs=active_configs,
                         expired_configs=expired_configs,
                         recent_configs=recent_configs,
                         criteria_stats=criteria_stats,
                         current_time=datetime.utcnow())

@app.route('/admin/configs')
@login_required
def admin_configs():
    """Liste de toutes les configurations"""
    page = request.args.get('page', 1, type=int)
    per_page = 50
    
    configs = UserConfig.query.order_by(
        UserConfig.created_at.desc()
    ).paginate(page=page, per_page=per_page, error_out=False)
    
    return render_template('admin_configs.html', configs=configs)

@app.route('/admin/deactivate-config/<config_id>', methods=['POST'])
@login_required
def deactivate_config(config_id):
    """Désactive une configuration"""
    config = UserConfig.query.filter_by(config_id=config_id).first()
    
    if config:
        config.is_active = False
        db.session.commit()
        flash(f'Configuration {config_id} désactivée', 'success')
    else:
        flash('Configuration non trouvée', 'error')
    
    return redirect(url_for('admin_configs'))

@app.route('/admin/stats')
@login_required
def admin_stats():
    """Statistiques détaillées"""
    # Génération par heure
    hourly_data = {}
    for i in range(24):
        hour = (datetime.utcnow() - timedelta(hours=i)).strftime('%Y-%m-%d %H:00')
        hourly_data[hour] = 0  # À remplacer par des données réelles
    
    # Top VPS
    top_vps = db.session.query(
        UserConfig.vps_ip,
        db.func.count(UserConfig.id).label('count')
    ).group_by(UserConfig.vps_ip).order_by(db.desc('count')).limit(10).all()
    
    return render_template('admin_stats.html',
                         hourly_data=hourly_data,
                         top_vps=top_vps)

@app.route('/admin/logout')
@login_required
def admin_logout():
    """Déconnexion admin"""
    logout_user()
    flash('Déconnexion réussie', 'success')
    return redirect(url_for('admin_login'))

# Commandes CLI pour l'initialisation
@app.cli.command('init-db')
def init_db():
    """Initialise la base de données"""
    db.create_all()
    
    # Créer l'utilisateur admin par défaut
    if not AdminUser.query.filter_by(username=app.config['ADMIN_USERNAME']).first():
        admin = AdminUser(
            username=app.config['ADMIN_USERNAME'],
            is_superadmin=True
        )
        admin.set_password(app.config['ADMIN_PASSWORD'])
        db.session.add(admin)
        db.session.commit()
        print('Base de données initialisée avec l\'utilisateur admin')
    else:
        print('Base de données déjà initialisée')

@app.cli.command('clean-expired')
def clean_expired():
    """Nettoie les configurations expirées"""
    expired = UserConfig.query.filter(
        UserConfig.expires_at < datetime.utcnow(),
        UserConfig.is_active == True
    ).all()
    
    for config in expired:
        config.is_active = False
    
    db.session.commit()
    print(f'{len(expired)} configurations expirées désactivées')

if __name__ == '__main__':
    # Créer les répertoires nécessaires
    os.makedirs('instance', exist_ok=True)
    
    # Lancer l'application
    app.run(host='0.0.0.0', port=5000, debug=True)