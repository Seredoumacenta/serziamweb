import json
from datetime import datetime, timedelta
from typing import Dict, List, Any

class PayloadStatsManager:
    """Gestionnaire des statistiques de payload"""
    
    def __init__(self):
        self.stats_file = 'payload_stats.json'
        self.stats = self._load_stats()
    
    def _load_stats(self) -> Dict[str, Any]:
        """Charge les statistiques depuis le fichier"""
        try:
            with open(self.stats_file, 'r') as f:
                return json.load(f)
        except:
            return {
                'total_configs_generated': 0,
                'active_configs': 0,
                'average_duration': 15,
                'most_popular_criterion': 'balanced',
                'performance_metrics': {
                    'economy': {'avg_compression': 97, 'avg_speed': 78, 'avg_reliability': 85},
                    'reliability': {'avg_compression': 92, 'avg_speed': 85, 'avg_reliability': 97},
                    'speed': {'avg_compression': 88, 'avg_speed': 97, 'avg_reliability': 90},
                    'balanced': {'avg_compression': 92, 'avg_speed': 90, 'avg_reliability': 92}
                },
                'hourly_generation': {},
                'last_updated': datetime.now().isoformat()
            }
    
    def _save_stats(self):
        """Sauvegarde les statistiques"""
        self.stats['last_updated'] = datetime.now().isoformat()
        with open(self.stats_file, 'w') as f:
            json.dump(self.stats, f, indent=2)
    
    def add_config_stat(self, criterion: str, duration_days: int, 
                       stats: Dict[str, Any]):
        """Ajoute une statistique de configuration"""
        self.stats['total_configs_generated'] += 1
        self.stats['active_configs'] += 1
        
        # Mettre à jour les métriques de performance
        perf = self.stats['performance_metrics'][criterion]
        perf['avg_compression'] = (perf['avg_compression'] + stats['compression_percentage']) / 2
        perf['avg_speed'] = (perf['avg_speed'] + stats['speed_percentage']) / 2
        perf['avg_reliability'] = (perf['avg_reliability'] + stats['reliability_percentage']) / 2
        
        # Mettre à jour la génération horaire
        hour = datetime.now().strftime('%Y-%m-%d %H:00')
        self.stats['hourly_generation'][hour] = self.stats['hourly_generation'].get(hour, 0) + 1
        
        self._save_stats()
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Récupère les statistiques de performance"""
        return self.stats['performance_metrics']
    
    def get_dashboard_stats(self) -> Dict[str, Any]:
        """Récupère les statistiques pour le tableau de bord"""
        return {
            'total_configs': self.stats['total_configs_generated'],
            'active_configs': self.stats['active_configs'],
            'most_popular': self.stats['most_popular_criterion'],
            'last_updated': self.stats['last_updated']
        }