python app.py
# ou
flask run --host=0.0.0.0 --port=5000